﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dog_Day_Care.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DogsController : ControllerBase
    {
        private static string temp = "xxx";
        private static string updated = "updated!";

        private static List<DogUsers> create_dogs = new List<DogUsers>
            {
                new DogUsers {
                    id = 1,
                    name = "Otty",
                    owner = "John McKenzy",
                    allergies = "Nuts",
                },

                new DogUsers {
                    id = 2,
                    name = "Spain",
                    owner = "Lazar Boa",
                    allergies = "Cheese"
                },

                new DogUsers {
                    id = 3,
                    name = "Majestic",
                    owner = "Lisa Michael",
                    allergies = "Cashew"
                }
            };


        [HttpGet]
        public async Task<ActionResult<List<DogUsers>>> Get()
        {
            /* IEnumerable<Users> Get()
            return Enumerable.Range(1, 3).Select(index => new Users { 
                id = index //  empty variables excet index }).ToArray(); */

            return Ok(create_dogs);
        }


        [HttpPost]
        public async Task<ActionResult<List<DogUsers>>> AddUser(DogUsers introduction)
        {
            create_dogs.Add(introduction);

            introduction.id = create_dogs.Count();
            introduction.name = temp;
            introduction.owner = temp;
            introduction.allergies = string.Format("{0}: none", temp);

            return Ok(create_dogs);
        }

        [HttpPut]
        public async Task<ActionResult<List<DogUsers>>> UpdateDogAllergies(DogUsers request, int id, string allergies)
        {
            var Dogs = create_dogs.Find(Find => Find.id == /*request.id*/ id);

            if (Dogs == null) return BadRequest("Error");

            Dogs.id = id;
            Dogs.allergies = allergies;

            /* Overwrite properties
                Dogs.owner = temp;
                Dogs.name = updated; 
            */

            return Ok(create_dogs);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<DogUsers>>> DeleteDogs(int id)
        {
            var delete_user = create_dogs.Find(Find => Find.id == id);

            create_dogs.Remove(delete_user);
            return Ok(create_dogs);
        }
    }
}
