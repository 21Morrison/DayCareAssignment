﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dog_Day_Care.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class CatsController : ControllerBase
    {

        private static List<CatUsers> create_cats = new List<CatUsers>
        {
            new CatUsers
            {
                id = 1,
                name = "Olly",
                owner = "Boa Boa",
                allergies = "Tuna"
            }
        };

        [HttpGet]
        public async Task<ActionResult<List<DogUsers>>> Get()
        {
            return Ok(create_cats);
        }

        [HttpPost]
        public async Task<ActionResult<List<CatUsers>>> Make(CatUsers cCats, string  cName, string cOwner, string cAllergies)
        {

            create_cats.Add(cCats);
            cCats.id = create_cats.Count();
            
            cCats.name = cName;
            cCats.owner = cOwner;
            cCats.allergies = cAllergies;

 
            return Ok(create_cats);
        }
    }
}
