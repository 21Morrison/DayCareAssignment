﻿namespace Dog_Day_Care
{
    public class CatUsers
    {
        public int id { get; set; }
        public string name { get; set; } = "";
        public string owner { get; set; } = "";
        public string allergies { get; set; } = "";
    }
}
